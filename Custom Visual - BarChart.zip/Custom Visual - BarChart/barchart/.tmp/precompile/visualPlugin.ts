import { Visual } from "../../src/visual";
var powerbiKey = "powerbi";
var powerbi = window[powerbiKey];

var barchart3DF94AA852F9456A9C902AF7D78BDCDF = {
    name: 'barchart3DF94AA852F9456A9C902AF7D78BDCDF',
    displayName: 'barchart',
    class: 'Visual',
    version: '1.0.0',
    apiVersion: '2.6.0',
    create: (options) => {
        if (Visual) {
            return new Visual(options);
        }

        console.error('Visual instance not found');
    },
    custom: true
};

if (typeof powerbi !== "undefined") {
    powerbi.visuals = powerbi.visuals || {};
    powerbi.visuals.plugins = powerbi.visuals.plugins || {};
    powerbi.visuals.plugins["barchart3DF94AA852F9456A9C902AF7D78BDCDF"] = barchart3DF94AA852F9456A9C902AF7D78BDCDF;
}

export default barchart3DF94AA852F9456A9C902AF7D78BDCDF;